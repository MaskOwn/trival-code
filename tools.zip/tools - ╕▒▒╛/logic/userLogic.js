var userLogic = {};

var web3Logic = require('../logic/web3Logic');

// 创建钱包账户
userLogic.createAccount = function () {
	return web3Logic.createAccount();
}

// 发送CDB
userLogic.sendCDB = function (sUser, iCount, callbackSuccess, callbackFailure) {
	web3Logic.sendCDB(sUser, iCount, callbackSuccess, callbackFailure);
}

// 获取用户CDB
userLogic.getBalance = function (sToken, callback) {
	web3Logic.getBalance(sToken, function (dBalance) {
		callback(dBalance);
	});
}

// 对项目进行投票
userLogic.support = function (sFromUser, sPK, sToUser, sProjectName, iCount, callbackSuccess, callbackFailure) {
	
	web3Logic.supportDocument(sFromUser, sPK, sToUser, sProjectName, iCount, function () {
		// 将投票信息上传到智能合约上
		callbackSuccess();
	}, function () {
		callbackFailure();
	});

}

// 支持数量
userLogic.supportCount = function (sProjectName, sProjectOwner, callbackSuccess) {
	web3Logic.getSupportCount(sProjectName, sProjectOwner, function (iScore) {
		callbackSuccess(iScore);
	});
}

module.exports = userLogic;
