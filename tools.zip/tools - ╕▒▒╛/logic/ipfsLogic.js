const ipfsAPI = require('ipfs-api')
const ipfs = ipfsAPI('0.0.0.0', '5001', {protocol: 'http'})
var fs = require('fs')
//var filepath = 'testdir/1.png' 
//var filehash = 'QmUrWcymPUhTa8huoZJkyPuq63V9q9yUiGgnLcYmShMUCW'
//var dirpath = 'testdir'
//var dirhash = 'QmVGQj37d8DVgo9xz2otDfz4MTd5NEDHFWTUQnDUJDs1CC'
//var projectpath = '/home/ethreum'
var ipfsio = {} ,privated = {}


ipfsio.downloadfile = function(filename,filehash,filepath,cb){
	const stream = ipfs.files.getReadableStream(filehash)
	stream.on('data', (file) => {
    // write the file's path and contents to standard out
    console.log(file.path)
    if(file.type !== 'dir') {
    	file.content.on('data', (data) => {
    		console.log(data.toString())
    		let writable = fs.createWriteStream(filepath+'/'+filename+'.txt');
    		writable.on('error', (err) => {
    			console.log('发生异常:', err);
			});
			writable.write(data.toString());
			writable.end();
    	})
    	file.content.resume()
    	cb(filename+'.txt')
		};
	})
};

ipfsio.uploadfile = function(filepath,cb){
	ipfs.files.add({
    	path : filepath,
    	content : fs.readFileSync(filepath)
    	}, (err, filesAdded) => {
    		if (err) { console.log(err) }
    		console.log('\nAdded file:', filesAdded[0].path)
    		cb(filesAdded[0].hash)

    })   

};

privated.readDirSync = function(dirpath,files=[]){
	var pa = fs.readdirSync(dirpath);
	pa.forEach(function(ele,index){
		var info = fs.statSync(dirpath+"/"+ele)	
		if(info.isDirectory()){
			//console.log("It' a dir")
			readDirSync(dirpath+"/"+ele,files);
		}else{
			//console.log("file: "+ele)
			files.push({
			path : dirpath+"/"+ele,
			content : fs.readFileSync(dirpath+"/"+ele)
			});
		}	
	})

	console.log(files);

};


ipfsio.uploaddir = function(dirpath,cb){
	var files = []
	privated.readDirSync(dirpath,files)
	const stream = ipfs.files.addReadableStream()
    stream.on('data', function (data) {
    	cb(data.path,data.hash)

  	})
    // Add the files one by one

    files.forEach(file => stream.write(file))
    // When we have no more files to add, close the stream
    stream.end()
};

ipfsio.lsdir = function(dirhash,callback){
	ipfs.ls(dirhash, function (err, files) {
		callback(files)
	})
}
ipfsio.downloadproject = function(projectpath,projecthash,cb){
	ipfsio.lsdir(projecthash,function(info){
		info.forEach(function(object){
			if(object.type == 'dir'){
				fs.mkdir(projectpath + '/' +object.name,function(err){
                	if(err){
                    	cb('创建文件夹出错！');
                	}else{
                    	cb('文件夹-创建成功！');
                    	ipfsio.downloadproject(projectpath + '/' +object.name,object.hash,cb)
                	}
            	});
			}else{
				ipfsio.downloadfile(object.name,object.hash,projectpath,cb)
			}
		})
	})
};
//lsdir(dirhsah,console.log)
//uploaddir(dirpath,console.log)

//uploadfile(filepath,console.log);

//download('./temp',filehash,console.log);
//ipfsio.downloadproject(projectpath,dirhash,console.log)
module.exports = ipfsio