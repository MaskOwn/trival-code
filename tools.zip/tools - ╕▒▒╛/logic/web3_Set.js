var Web3 = require('web3');

var web3 = new Web3('ws://47.106.90.70:8547');

var sMainAddress = '0x00fE4Fae79a2AC3b205701B8BAd297e80BF988a4';

var abi =  [
    {
      "constant": true,
      "inputs": [
        {
          "name": "",
          "type": "address"
        }
      ],
      "name": "mappingUser",
      "outputs": [
        {
          "name": "num",
          "type": "uint256"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "a",
          "type": "string"
        },
        {
          "name": "b",
          "type": "string"
        }
      ],
      "name": "isEqual",
      "outputs": [
        {
          "name": "",
          "type": "bool"
        }
      ],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "addr",
          "type": "address"
        },
        {
          "name": "filename",
          "type": "string"
        },
        {
          "name": "hash",
          "type": "string"
        }
      ],
      "name": "setCodehash",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": true,
      "inputs": [
        {
          "name": "addr",
          "type": "address"
        },
        {
          "name": "filename",
          "type": "string"
        }
      ],
      "name": "getCodehash",
      "outputs": [
        {
          "name": "hash",
          "type": "string"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "constant": false,
      "inputs": [
        {
          "name": "a",
          "type": "string"
        },
        {
          "name": "b",
          "type": "string"
        }
      ],
      "name": "stringAdd",
      "outputs": [
        {
          "name": "",
          "type": "string"
        }
      ],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "constant": true,
      "inputs": [
        {
          "name": "addr",
          "type": "address"
        }
      ],
      "name": "getFilenames",
      "outputs": [
        {
          "name": "",
          "type": "string"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "constant": true,
      "inputs": [
        {
          "name": "addr",
          "type": "address"
        },
        {
          "name": "filename",
          "type": "string"
        }
      ],
      "name": "getSpecialCode",
      "outputs": [
        {
          "name": "hash",
          "type": "string"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    }
  ];

// eth
var SetandgetContractAddress = '0x593025e886bd8b6bfd9bc60978e38fb46f2e624f';


var PrivateKey = '0x61130b9be2839db910cb641ff8254deed52fe9c9b173855f28f36ee9a171c5ee'

// 合约对象
var SetandgetContract = new web3.eth.Contract(abi,SetandgetContractAddress);

var web3Logic = {};


web3Logic.setCodehash = function(addr,filename,hash){


    var SetABI = SetandgetContract.methods.setCodehash(addr,filename,hash).encodeABI();

    console.log(SetABI);

    var tx = {
        from: sMainAddress,
        to: SetandgetContractAddress,
        data: SetABI,
        // gasPrice: "20000000000000000",
        gas :'4600000'
    }
    //console.log("SetABI:" + SetABI);
    console.log("set " + addr + ":"  + filename + ":" + hash);

    web3.eth.accounts.signTransaction(tx, PrivateKey).then(function(data) {

            web3.eth.sendSignedTransaction(data.rawTransaction)
            .on('transactionHash', function(hash){
              console.log('transactionHash');
              console.log(hash);
            })
            .on('receipt', function(receipt){
              console.log('receipt');
              console.log(receipt);
              //callback(null, receipt);
            })
            .on('error', function(error){
              console.log('error');
              console.log(error);
              //callback(error, null);
            });
        });
}

/*
web3Logic.addCodehash = function(addr,hash,callback){
    var getcode = web3Logic.getCodehash(testaddress1,add);
}
*/

web3Logic.getCodehash = function(addr,filename,cb){

    SetandgetContract.methods.getCodehash(addr,filename).call().then(function(hash){
        //var hash = hash.toString().split(",");
        console.log(hash);
        cb(hash);
    });
}

web3Logic.getFilenames = function(addr,cb){
    SetandgetContract.methods.getFilenames(addr).call().then(function(names){
        var projectnames = names.split(',').slice(1)
        cb(projectnames);

    });
}


module.exports = web3Logic