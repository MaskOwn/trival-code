var Web3 = require('web3');
var web3 = new Web3('ws://47.106.90.70:8547');

var web3Logic = {};

web3Logic.iRand = 0;

var sMainAddress = '0x008510239e72dEe37C0C56D3E235D2Eb9fBF3D0D';
var sPK = "0xf42b7018056eece91837d82fb47f56e67769af39face959178ae0e77a819729b";

// 创建钱包账号
web3Logic.createAccount = function () {
	var userInfo  = web3.eth.accounts.create();
	console.log(userInfo);
	return userInfo;
}

// 获取当前钱包的余额
web3Logic.getBalance = function (sToken, callback) {
	web3.eth.getBalance(sToken).then(function (dBalance) {
		callback(dBalance);
	});
}

// 发送CDB给token
web3Logic.sendCDB = function (sUser, iCount, callbackSuccess, callbackFailure) {

	var account = web3Logic.getMainAccount();

	var tx = {
		from: account.sMainAddress,
	    to: sUser,
	    value: iCount
	};

	console.log(account.sMainAddress + "|" + account.sPrivateKey);

	web3.eth.estimateGas(tx).then(function(gas) {

		tx.gas = gas;

		web3.eth.accounts.signTransaction(tx, account.sPrivateKey).then(function(data) {
 	
			web3.eth.sendSignedTransaction(data.rawTransaction)
			.on('transactionHash', function(hash){
		    	console.log('transactionHash');
		    	console.log(hash);
		    	callbackSuccess();
		    })
		    .on('receipt', function(receipt){
		    	console.log('receipt');
		    	console.log(receipt);
		    })
		    .on('error', function(error){
		    	console.log('error');
		    	console.log(error);
		    	callbackFailure();
		    });

		});
	});

}

// 给指定用户发送CDB
// sFromUser: 发送CDB者
// sPK : 发送者私钥
// sToUser: 给指定的人
// iCount: 发送CDB的数量
// callbackSuccess: 成功的回调
// callbackFailure: 失败的回调
web3Logic.sendCDBFrom = function (sFromUser, sPK, sToUser, iCount, callbackSuccess, callbackFailure) {

	var tx = {
		from: sFromUser,
	    to: sToUser,
	    value: iCount
	};

	web3.eth.estimateGas(tx).then(function(gas) {

		tx.gas = gas;

		web3.eth.accounts.signTransaction(tx, sPK).then(function(data) {
 	
			web3.eth.sendSignedTransaction(data.rawTransaction)
			.on('transactionHash', function(hash){
		    	console.log('transactionHash');
		    	console.log(hash);
		    	callbackSuccess();
		    })
		    .on('receipt', function(receipt){
		    	console.log('receipt');
		    	console.log(receipt);
		    })
		    .on('error', function(error){
		    	console.log('error');
		    	console.log(error);
		    	callbackFailure();
		    });

		});
	});

}

// 获取主账号名称
web3Logic.getMainAccount = function () {

	var account = {};

	if (web3Logic.iRand == 0) {
		account.sMainAddress = sMainAddress;
		account.sPrivateKey = sPK;
		web3Logic.iRand++;
	} else {
		account.sMainAddress = "0x3E05A0b12a6D95480915EBa938F5De09ccF2f620";
		account.sPrivateKey = "0x047f8ec0f685201737b6cc1fa7afba76376227d34f070da3c89c1a46f9c15b81";
		web3Logic.iRand = 0;
	}

	return account;
}

// 智能合约地址
var MedalContractAddress = '0x3eecf4305656ce0425b17ceef195ca1ffc8f74cd';

// 智能合约ABI
var MedalContractABI = [{"constant":true,"inputs":[],"name":"sellPrice","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"sProjectName","type":"string"},{"name":"owner","type":"address"},{"name":"iCount","type":"uint256"}],"name":"supportDocument","outputs":[{"name":"","type":"bool"}],"payable":true,"stateMutability":"payable","type":"function"},{"constant":true,"inputs":[{"name":"sProjectName","type":"string"}],"name":"getSupport","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"}];

// 智能合约对象
var SupportContract = new web3.eth.Contract(MedalContractABI, MedalContractAddress);

// 给指定项目投票
// sFromUser: 投票者
// sPK: 投票者私钥
// sProjectOwner: 项目拥有者
// sProjectName: 项目名
// iCount: 投票数量
// callbackSuccess: 成功回调
// callbackFailure: 失败回调
web3Logic.supportDocument = function (sFromUser, sPK, sProjectOwner, sProjectName, iCount, callbackSuccess, callbackFailure) {

	var sKey = sProjectOwner + "/" + sProjectName;

	// 合约要执行的方法
	var funABI = SupportContract.methods.supportDocument(sKey, sProjectOwner, iCount).encodeABI();

	var tx = {
		from: sFromUser,
        to: MedalContractAddress,
        value: 1000000000000000000 * iCount,
        data: funABI
    }

	//  执行该合约需要的gas
	web3.eth.estimateGas(tx).then(function(gas) {
        
      	// 需要的gas
        tx.gas = gas;

    	web3.eth.accounts.signTransaction(tx, sPK).then(function(data) {
	    
		    web3.eth.sendSignedTransaction(data.rawTransaction)
		    .on('transactionHash', function(hash){
	    	    console.log(hash);
	        })
	        .on('receipt', function(receipt) {
	        	console.log(receipt);
	    	    callbackSuccess();
	        })
	        .on('error', function(error){
	    	    console.log("error --> " + error);
	    	    callbackFailure();
	        });

	    });
    });

}

// 获取支持数量
web3Logic.getSupportCount = function (sProjectName, sProjectOwner, callbackSuccess) {

	var sKey = sProjectOwner + "/" + sProjectName;
	
	SupportContract.methods.getSupport(sKey).call().then(function (iScore) {
		callbackSuccess(iScore);
	});

}

module.exports = web3Logic;
