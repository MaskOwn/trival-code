const ipfsAPI = require('ipfs-api');
const ipfs = ipfsAPI('0.0.0.0', '5001', {protocol: 'http'});
var fs = require('fs');

var ipfsTool = {};

// 用户的项目路径
ipfsTool.getUserHomePath = function (sAddress) {
	var sPath = '/coderchain/' + sAddress;
	return sPath;
}

// 项目名
ipfsTool.getProjectPath = function (sAddress, sProjectName) {
	var sPath = '/coderchain/' + sAddress + "/" + sProjectName;
	return sPath;
}

// 创建目录的方法并获得hash
ipfsTool.createPath = function (sPath, cbSuccess, cbFailure) {
	
	ipfs.files.mkdir(sPath, (err) => {

		if (err) {
	    	console.error(err);
	    	cbFailure(err);
	    	return;
	  	}

	  	ipfs.files.stat(sPath, (err, stats) => {

	  		if (err) {
	  			cbFailure(err);
	  			return;
	  		}

	  		console.log(stats);
		  	cbSuccess(stats.hash);
		})

	});

}

// 删除目录
ipfsTool.removePath = function (sPath, cbSuccess, cbFailure) {
	
	ipfs.files.rm(sPath, { recursive: true }, (err) => {
  		if (err) {
    		console.error(err);
    		cbFailure(err);
    		return;
  		}
  		cbSuccess();
	});
}

// 项目列表
ipfsTool.ls = function (sPath, cbSuccess, cbFailure) {

	ipfs.files.ls(sPath, function (err, files) {

		if (err) {
			console.log(err);
			cbFailure(err);
			return;
		}

		var arrDir = [];

		var iCount = files.length;
		var iIndex = 0;

		files.forEach((file) => {
    		// console.log(file.name)
    		ipfs.files.stat(sPath + "/" + file.name, (err, stats) => {

    			iIndex++;

    			if (err) {
    				console.log(err);
    			} else {
    				stats.name = file.name;
    				arrDir.push(stats);
    			}

  				if (iCount == iIndex) {
  					// 代表目录数据读取完毕
  					cbSuccess(arrDir);
  				}

			});
  		});

  		if (iCount == 0) {
  			cbSuccess(arrDir);
  		}

	});
}

// 往某个文件写内容
ipfsTool.write = function (sFilePath, sData, cbSuccess, cbFailure) {

	ipfs.files.write(sFilePath, Buffer.from(sData), { create: true }, (err) => {
		if (err) {
			cbFailure(err);
			return;
		}

		cbSuccess();
	});

}

module.exports = ipfsTool;
